<?php
$assets_url = ASSETS_URL;
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>eShopper Online Store</title>
		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/bootstrap.min.css">
  		<script src="<?php echo $assets_url; ?>js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/style.css" >
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/media.css" >
	</head>
	<body>
		<!--	Main content 	-->
		<header class="header-data">
			<img src="<?php echo $assets_url; ?>images/inner-banner.jpg">
		</header>
		<a id="topBtn" title="Go to top"><img class="up-arrow" src="<?php echo $assets_url; ?>images/img_transparent.png"></div></a>
		<div class="container">
			<div class="background-content">
				<div class="row">
					<div class="col-sm-12 col-xs-12 padding-breadcrumb">
						<ul class="breadcrumb">
							<li>Home</li>
							<li class="last-item">Contact Us</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="contact-us">
				<h2>Contact Us</h2>
			</div>
			<div class="row">
				<div class="col-lg-9 col-sm-9 col-xs-12">
					<form action="<?php echo SITE_URL; ?>contact/contactEshop" method="post">
						<div class="row">
							<div class="col-sm-6 col-xs-12">
								<div class="form-group">
								    <label for="name">Name</label>
								    <input type="text" class="form-control" id="name" name="name" placeholder="Please enter your name" required="">
								</div>
								<div class="form-group">
								    <label for="email">Email</label>
								    <input type="email" class="form-control" id="email" name="email" placeholder="Please enter valid email" required="">
								</div>
								<div class="form-group">
								    <label for="subject">Subject</label>
								    <input type="text" id="subject" placeholder="Please enter Subject" name="subject" class="form-control" required="">
								</div>
							</div>
							<div class="col-sm-6 col-xs-12">
								<div class="form-group">
								    <label for="message">Message</label>
								   	<textarea id="message" class="form-control message-size" name="message" placeholder="Your message here" required=""></textarea>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12 col-sm-12">
								<input type="submit" value="Submit" class="btn contact-btn-style pull-right">
							</div>
						</div>
					</form>
					<div class="row margin-map">
						<div class="col-lg-8 col-md-12 -col-sm-12 col-xs-12">
							<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3671.7059025790086!2d72.5005469!3d23.0345682!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e8352e403437b%3A0xdc9d4dae36889fb9!2sTatvaSoft!5e0!3m2!1sen!2sin!4v1516170056549" width="550" height="400" frameborder="0" style="border:0" class="map-size" allowfullscreen></iframe>
						</div>
						<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 text">
							<h4><b>Get in touch</b></h4>
							<p>Tatvasoft House,<br>
							Rajpath Club Road,<br>
							Near Shivalik Business Center,<br>
							Opp. Golf Academy,<br>
							Off S G  Road, Ahmedabad,<br>
							Gujarat 380054</p>
							<div class="row">
								<div class="col-sm-2 col-xs-3">
									Phone:
								</div>
								<div class="col-sm-10 col-xs-9 last-item">
									(03)555 55555
								</div>
							</div>
							<div class="row">
								<div class="col-sm-2 col-xs-3">
									Email:
								</div>
								<div class="col-sm-10 col-xs-9 last-item">
									info@tatvasoft.com
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-3 col-xs-12">
					<div class="image image-responsive">
						<div class="promo">
							<a href="<?php echo $assets_url; ?>images/promo1.jpg"><img src="<?php echo $assets_url; ?>images/promo1.jpg" alt="promo1"></a>
							<a href="<?php echo $assets_url; ?>images/promo1.jpg"><img src="<?php echo $assets_url; ?>images/promo2.jpg" alt="promo2"></a>
						</div>
					</div>
				</div>
			</div>
		</div>