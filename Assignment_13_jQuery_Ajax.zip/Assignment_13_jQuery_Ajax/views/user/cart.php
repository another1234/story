<?php
$assets_url = ASSETS_URL;
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>eShopper Online Store</title>
		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/bootstrap.min.css">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  		<script type="text/javascript" src="<?php echo $assets_url; ?>js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/style.css" >
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/media.css" >
	</head>
	<body onload="changeSubtotal();">
		<!--	Main content 	-->
		<header class="header-data-banner">
			<img src="<?php echo $assets_url; ?>images/inner-banner.jpg">
		</header>
		<a id="topBtn" title="Go to top"><img class="up-arrow" src="<?php echo $assets_url; ?>images/img_transparent.png"></div></a>
		<div class="container">
			<div class="background-content">
				<div class="row">
					<div class="col-sm-12 col-xs-12 padding-breadcrumb">
						<ul class="breadcrumb">
							<li>Home</li>
							<li class="last-item">Shopping Cart</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="shopping-cart">
				<h2>Shopping Cart</h2>
			</div>
			<div class="row">
				<div class="col-sm-12 col-xs-12 collapse" id="updateAlert">
				  	<div class="alert alert-success alert-dismissable">
				    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
				    	<div class="row">
				    		<div class="col-sm-1 col-xs-1 success-icon">
				    		</div>
				    		<div class="col-sm-11 col-xs-11 data-display" id="updateItem">
				    		</div>
				    	</div>
				  	</div>
				</div>
				<div class="col-sm-12 col-xs-12 collapse" id="removeAlert">
				  	<div class="alert alert-danger alert-dismissable">
				    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
				    	<div class="row">
				    		<div class="col-sm-1 col-xs-1 error-icon">
				    		</div>
				    		<div class="col-sm-11 col-xs-11 data-display" id="removeItem">
				    		</div>
				    	</div>
				  	</div> 
				</div>
		  	</div>
		  	<?php
		  	if(!empty($_SESSION["cart"])){
		  	?>
		  	<div class="table-responsive">
		  		<table width="100%" class="table">
					<thead>
					  <tr>
					    <td></td><td>Product Name</td><td></td><td>Unit Price</td><td>Qty</td><td>Subtotal</td><td></td>
					  </tr>
					</thead>
					<?php
					// echo "<pre>";print_r($_SESSION["cart"]);exit();
					foreach ($_SESSION["cart"] as $cartItem) {
						$totalPerItem=$cartItem['price']*$cartItem['qty'];
						$subtotal+=$totalPerItem;
					?>
					<tbody>
					 	<tr>
					        <td class="tbl-image">
					        	<img src="<?php echo $assets_url; ?>images/<?php echo $cartItem['item_image_url']; ?>" />
					        </td>
					        <td>
					        	<?php echo $cartItem['name']; ?><br>
					        	<b>Color</b><br>
					        	<?php echo $cartItem['color']; ?><br>
					        	<b>Size</b><br>
					        	<?php echo $cartItem['value']; ?><br>
					        </td>
					        <td class="td-width">
					        	<div class="edit" title="<?php echo $cartItem['id']; ?>"></div><input type="hidden" value="<?php echo $cartItem['id']; ?>" name="itemId">
					        </td>
					        <td class="last-item">
					        	$<div class="display-price" name="price_js"><?php echo $cartItem['price']; ?></div>.00
					        </td>
					        <td>
					        	<input type="text" onkeyup="changeSubtotal()" name="qty_js" id="qty<?php echo $cartItem['id']; ?>"  class="qty-border qty<?php echo $cartItem['id']; ?>" value="<?php echo $cartItem['qty']; ?>" readonly>
					        </td>
					        <td class="last-item">
					        	$<div id="subtotal_js" class="subtotal_js display-price" name="subtotal_js"><?php echo $cartItem['price']; ?></div>.00
					        </td>
					        <td class="td-width">
					        	<a><div class="cancel" title="<?php echo $cartItem['id']; ?>"></div></a>
					        </td>
						</tr>
					</tbody>
					<?php
					}
					?>
					<tbody>
					    <tr class="row-background-color">
					        <td colspan="4">
					          <input class="btn cart-btn" type="submit" value="Continue Shopping">
					        </td>
					        <td colspan="3" class="align-btn">
					          	<a class="btn cart-btn" onclick="return confirm('Are you sure, you want to clear cart?');" href="<?php echo SITE_URL; ?>cart/clearShoppingCart">Clear Shopping Cart</a>
					          	<input type="button" id="update-cart" class="btn cart-btn" value="Update Shopping Cart">
					        </td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="row">
				<div class="col-sm-5 col-xs-12">
					<div class="panel panel-default">
					    <div class="panel-body">
							<h4>Estimate Shipping and Tax</h4>
							<p>Enter your destination to get a shipping estimate.</p>
							<form>
								<div class="form-group group-height">
								    <label for="country">Country</label>
								    <select class="form-control">
									  	<option>Option1</option>
									  	<option>Option2</option>
									</select>
							  	</div>
							  	<div class="form-group group-height">
								    <label for="state">State/Province</label>
								    <input type="text" class="form-control" id="state" placeholder="State/Province">
							  	</div>
							  	<div class="form-group group-height">
								    <label for="zipcode">Zip/Postal Code</label>
								    <input type="text" class="form-control" id="zipcode" placeholder="Zip/Postal Code">
							  	</div>
							</form>
						</div>
					</div>
				</div>
				<div class="col-sm-offset-3 col-sm-4 col-xs-12">
					<div class="panel panel-default">
					    <div class="panel-body">
					    	<div class="row">
					    		<div class="col-sm-offset-6 col-sm-3 col-xs-offset-4 col-xs-4">Subtotal</div>
					    		<div class="col-sm-3 col-xs-4" id="subtotal">$<?php echo $subtotal; ?>.00</div>
					    		<!-- <input type="hidden" id="finalAmount"> -->
					    	</div>
					    	<div class="row">
					    		<div class="col-sm-offset-6 col-sm-3 col-xs-offset-4 col-xs-4 total">Total</div>
					    		<div class="col-sm-3 col-xs-4 last-item total data-margin" id="total">$<?php echo $subtotal; ?>.00</div>
					    	</div>
					    	<div class="row">
					    		<div class="col-sm-12 col-xs-12"><input type="submit" id="update-shopping-cart" value="Update Shopping Cart" class="btn submit-btn"></div>
					    	</div>
					    </div>
					    <div class="panel-footer footer-center">Checkout with multiple addresses</div>
					</div>
				</div>
			</div>
			<?php
			}
			else{
		  		?>
		  		<div class="row">
		  			<div class="col-sm-12 col-xs-12" id="repeatAlert">
					  	<div class="alert alert-danger alert-dismissable">
					    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
					    	<div class="row">
					    		<div class="col-sm-1 col-xs-1 error-icon">
					    		</div>
					    		<div class="col-sm-11 col-xs-11 data-display" id="repeatMsg">
					    			Cart is empty
					    		</div>
					    	</div>
					  	</div> 
					</div>
		  		</div>
		  		<?php
		  		$address=SITE_URL . "home";
		  		echo "<script>";
		        echo "window.location.replace(\"$address\");";
		        echo "</script>";
		  	}
			?>
		</div>
		<!-- <script type="text/javascript" src="<?php echo $assets_url; ?>js/data.js"></script> -->
	</body>
</html>