<?php
$assets_url = ASSETS_URL;
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>eShopper Online Store</title>
		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/bootstrap.min.css">
  		<script type="text/javascript" src="<?php echo $assets_url; ?>js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/style.css" >
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/media.css" >
	</head>
	<body>
		<!--	Main content 	-->
		<header class="header-data">
			<img src="<?php echo $assets_url; ?>images/inner-banner.jpg">
		</header>
		<a id="topBtn" title="Go to top"><img class="up-arrow" src="<?php echo $assets_url; ?>images/img_transparent.png"></div></a>
		<div class="container margin-end">
			<div class="about-us">
				<h2>About Us</h2>
			</div>
			<div class="row">
				<div class="col-lg-9 col-sm-9 col-xs-12">
					<section>
						<h1>Welcome to the Website</h1>
						<p>Cascading Style Sheets, or CSS, are a way to change the look of HTML and XHTML web pages. 
						CSS was designed by the W3C, and is supported well by most modern web browsers. The current 
						version of CSS is CSS3. CSS4 is available, but is split into parts.The prefers to all HTML 
						elements with the <code>&lt;p&gt;</code> tag. The CSS is being used to change this element. 
						The color and font-size are both properties and the blue and 120% are values. 
						Each property has a set of possible values. These values can be words or numbers.</p>
					</section>
					<section>
						<h2>Media File Audio/video</h2>
						<p>Most other video players require you to install third party software ("codecs") that enable 
						support for the particular type of file you wish to play. Not so with Final Media Player - 
						it includes everything you need.</p>
						<div class="row">
							<div class="col-lg-6 col-sm-6 col-xs-12">
								<div class="embed-responsive embed-responsive-16by9">
									<video controls>
									  <source src="<?php echo $assets_url; ?>images/video.mp4" type="video/mp4">
									  <source src="<?php echo $assets_url; ?>images/video.ogg" type="video/ogg">
									Your browser does not support the video tag.
									</video>
								</div>
								<h3>Video Extensions</h3>
								<ul>
									<li>MP4</li>
									<li>FLV</li>
									<li>MKV</li>
									<li>AVI</li>
								</ul>
							</div>
							<div class="col-lg-6 col-sm-6 col-xs-12">
								<div class="image image-responsive">
									<img src="<?php echo $assets_url; ?>images/cms-img2.jpg" alt="img"/>
								</div>
								<h3>Image Extensions</h3>
								<ul>
									<li>JPG</li>
									<li>PNG</li>
									<li>GIF</li>
									<li>BMP</li>
								</ul>
							</div>
						</div>
					</section>
					<section>
						<h2>Media File Image</h2>
						<p>Most other video players require you to install third party software ("codecs") that enable 
						support for the particular type of file you wish to play. Not so with Final Media Player - it 
						includes everything you need.</p>
						<div class="row">
							<div class="col-lg-4 col-sm-4 col-xs-12">
								<div class="image image-responsive">
									<img src="<?php echo $assets_url; ?>images/cms-img3.jpg">
								</div>
								<h4>Image 1</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, 
								nulla et dictum interdum...</p>
							</div>
							<div class="col-lg-4 col-sm-4 col-xs-12">
								<div class="image image-responsive">
									<img src="<?php echo $assets_url; ?>images/cms-img4.jpg">
								</div>
								<h4>Image 2</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, 
								nulla et dictum interdum...</p>
							</div>
							<div class="col-lg-4 col-sm-4 col-xs-12">
								<div class="image image-responsive">
									<img src="<?php echo $assets_url; ?>images/cms-img5.jpg">
								</div>
								<h4>Image 3</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, 
								nulla et dictum interdum...</p>
							</div>
						</div>
					</section>
					<section>
						<h2>Media File Image</h2>
						<p>Most other video players require you to install third party software ("codecs") that enable 
						support for the particular type of file you wish to play. Not so with Final Media Player - it 
						includes everything you need.</p>
						<div class="row">
							<div class="col-lg-6 col-sm-6 col-xs-12">
								<div class="image image-responsive">
									<img src="<?php echo $assets_url; ?>images/cms-img6.jpg" alt="img"/>
								</div>
								<h5>Video Extensions</h5>
								<ol type="i">
									<li>MP4</li>
									<li>FLV</li>
									<li>MKV</li>
									<li>AVI</li>
								</ol>
							</div>
							<div class="col-lg-6 col-sm-6 col-xs-12">
								<div class="image image-responsive">
									<img src="<?php echo $assets_url; ?>images/cms-img7.jpg" alt="img"/>
								</div>
								<h5>Image Extensions</h5>
								<ol type="i">
									<li>JPG</li>
									<li>PNG</li>
									<li>GIF</li>
									<li>BMP</li>
								</ol>
							</div>
					</section>
				</div>
				<div class="col-lg-3 col-sm-3 col-xs-12">
					<div class="image image-responsive">
						<div class="promo">
							<a href="<?php echo $assets_url; ?>images/promo1.jpg"><img src="<?php echo $assets_url; ?>images/promo2.jpg" alt="promo2"></a>
							<a href="<?php echo $assets_url; ?>images/promo1.jpg"><img src="<?php echo $assets_url; ?>images/promo1.jpg" alt="promo1"></a>
						</div>
					</div>
				</div>
			</div>
		</div>