<?php

class ProductModel extends basemodel
{
	public function fetchProducts(){
		$getProducts="SELECT `item_options`.id,`item`.id as item_id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1";
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
	public function fetchProductByColor($id){
		$getProducts="SELECT `item_options`.id,`item`.id as item_id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1 AND `item`.color_id=$id";
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
	public function fetchProductByPrice($startRange,$endRange){
		$getProducts="SELECT `item_options`.id,`item`.id as item_id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1 AND `item`.price BETWEEN $startRange AND $endRange";
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
	public function fetchProductBySize($id){
		$getProducts="SELECT `item_options`.id,`item`.id as item_id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1 AND `attribute_options`.id=$id";
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
	public function fetchSubcategory(){
		// $getProductSubcategory="SELECT `id`, `name` FROM `category` WHERE `parent_id`=1";
		$getProductSubcategory="SELECT `item`.`id`,  `category`.`name`,COUNT(`item_options`.item_id) as 'count'
								FROM `item_options`
								LEFT JOIN `item` ON `item`.id=`item_options`.item_id
								LEFT JOIN `category` ON `category`.id=`item`.category_id
								WHERE `category`.id=`item`.category_id AND `category`.parent_id=1
								GROUP BY `item_options`.item_id";
		$result=$this->_db->query($getProductSubcategory);
		return $this->getResultArray($result);
	}
	public function fetchColor(){
		$getProductColor="SELECT `item`.`id`,`item`.color_id , `attribute_options`.`value`,COUNT(`item_options`.item_id) as 'count'
							FROM `item_options`
							LEFT JOIN `item` ON `item`.id=`item_options`.item_id
							LEFT JOIN `attribute_options` ON `attribute_options`.id=`item`.color_id
							WHERE `attribute_options`.id=`item`.color_id
							GROUP BY `item`.color_id";
		$result=$this->_db->query($getProductColor);
		return $this->getResultArray($result);
	}
	public function fetchPrice(){
		// $getProductColor="SELECT `id`,  `value` FROM `attribute_options` WHERE `attribute_id`=2";
		$getProductPrice="SELECT min(price) as 'minPrice',max(price) as 'maxPrice' FROM `item`";
		$result=$this->_db->query($getProductPrice);
		return $this->getResultArray($result);
	}
	public function fetchSize(){
		// $getProductSize="SELECT `id`,  `value` FROM `attribute_options` WHERE `attribute_id`=1";
		$getProductSize="SELECT `attribute_options`.`id`,  `attribute_options`.`value`,COUNT(`item_options`.ao_id) as 'count'
						FROM `item_options`
						LEFT JOIN `item` ON `item`.id=`item_options`.item_id
						LEFT JOIN `attribute_options` ON `attribute_options`.id=`item_options`.ao_id
						GROUP BY `item_options`.ao_id";
		$result=$this->_db->query($getProductSize);
		return $this->getResultArray($result);
	}
	public function getSize($id) 
	{
		$getSize="SELECT `item_options`.id,`attribute_options`.value
				FROM `item_options` 
                LEFT JOIN `item` ON `item`.id=`item_options`.item_id
				LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
				WHERE `item_options`.item_id=$id";
		$result=$this->_db->query($getSize);
		return $this->getResultArray($result);
	}
	public function getImages($item_id) 
	{
		$getImages="SELECT * FROM item_images WHERE item_id=$item_id";
		$result=$this->_db->query($getImages);
		return $this->getResultArray($result);
	}
	public function getReviews($item_id) 
	{
		$getReviews="SELECT `item_review`.review_text,`item_review`.ratings,`item_review`.review_date,`user`.firstname,`item`.name FROM `item_review` LEFT JOIN `item` ON `item`.id=`item_review`.item_id LEFT JOIN `user` ON `item_review`.user_id=`user`.id WHERE `item_review`.item_id=$item_id ORDER BY `item_review`.id DESC";
		$result=$this->_db->query($getReviews);
		return $this->getResultArray($result);
	}
	public function getImageDescription($item_id) 
	{
		$getImageDescription="SELECT * FROM item WHERE id=$item_id";
		$result=$this->_db->query($getImageDescription);
		return $this->getResultArray($result);
	}
	public function addToWishList($item_id,$user_id) 
	{
		$uniqWishList="SELECT item_id,user_id FROM wishlist WHERE item_id=$item_id AND user_id=$user_id";
		if($this->_db->query($uniqWishList)->num_rows==0){
			$addToWishList="INSERT INTO `wishlist`(`item_id`, `user_id`) VALUES ($item_id,$user_id)";
			$result=$this->_db->query($addToWishList);
			return $result;
		}
		else{
			return false;
		}
	}
	public function addReview($item_id,$user_id,$msg,$ratings){
		$date=date("Y-m-d H:i:s");
		$uniqReview="SELECT item_id,user_id FROM item_review WHERE item_id=$item_id AND user_id=$user_id";
		if($this->_db->query($uniqReview)->num_rows==0){
			$addReview="INSERT INTO `item_review`(`user_id`, `item_id`, `review_text`, `ratings`, `review_date`) VALUES ($user_id,$item_id,'$msg',$ratings,'$date')";
			// echo $addReview;exit();
			if($this->_db->query($addReview)){
				$selectReviews="SELECT `item_review`.review_text,`item_review`.ratings,DATE_FORMAT(`item_review`.review_date, '%d-%m-%Y') as review_date,`user`.firstname,`item`.name FROM `item_review` LEFT JOIN `item` ON `item`.id=`item_review`.item_id LEFT JOIN `user` ON `item_review`.user_id=`user`.id WHERE `item_review`.item_id=$item_id ORDER BY `item_review`.id DESC LIMIT 1";
				// echo $selectReviews;exit();
				$result=$this->_db->query($selectReviews);
				return $this->getResultArray($result);
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}
}
?>