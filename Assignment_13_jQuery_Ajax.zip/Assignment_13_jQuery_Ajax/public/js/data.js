var rows = [
      {
        img: assets_url + 'images/2.jpg',
        product: 'U.S. Polo Assn. Full Sleeve Plain T-Shirts for Men<br><b>Color</b><br>Blue<br><b>Size</b><br>M',
        price: 222.00,
        qty: 1,
      },
      {
        img: assets_url + 'images/2.jpg',
        product: 'U.S. Polo Assn. Full Sleeve Plain T-Shirts for Men<br><b>Color</b><br>Blue<br><b>Size</b><br>M',
        price: 240.00,
        qty: 4,
      },
      {
        img: assets_url + 'images/2.jpg',
        product: 'U.S. Polo Assn. Full Sleeve Plain T-Shirts for Men<br><b>Color</b><br>Blue<br><b>Size</b><br>M',
        price: 224.00,
        qty: 3,
      },
      {
        img: assets_url + 'images/2.jpg',
        product: 'U.S. Polo Assn. Full Sleeve Plain T-Shirts for Men<br><b>Color</b><br>Blue<br><b>Size</b><br>M',
        price: 252.00,
        qty: 2,
      }  
];
var total=0;
for (var i = 0; i < rows.length; i++) {
    total=total+(rows[i]["price"]*rows[i]["qty"]);
}
var table_data = `<table width="100%" class="table">
<thead>
  <tr>
    <td></td><td>Product Name</td><td></td><td>Unit Price</td><td>Qty</td><td>Subtotal</td><td></td>
  </tr>
</thead>
<tbody>
  ${
        rows.map(cols => 
        `<tr>
        <td class="tbl-image"><img src="${cols.img}" /></td>
        <td>${cols.product}</td>
        <td><div class="edit"></div></td>
        <td class="last-item"><div name="price_js">${cols.price}</div></td>
        <td><input type="text" onkeyup="changeSubtotal()" name="qty_js"  class="qty-border" value="${cols.qty}"></td>
        <td class="last-item"><div id="subtotal_js" class="subtotal_js" name="subtotal_js">${cols.price*cols.qty}</div></td>
        <td><div class="cancel"></div></td>
        </tr>`
        ).join('')
  }
</tbody>
<tbody>
      <tr class="row-background-color">
        <td colspan="4">
          <input class="btn cart-btn" type="submit" value="Continue Shopping">
        </td>
        <td colspan="3" class="align-btn">
          <input class="btn cart-btn" type="submit" value="Clear Shopping Cart">
          <input type="submit" class="btn cart-btn" value="Update Shopping Cart">
        </td>
      </tr>
</tbody>
</table>`;

document.querySelector('#cart-table').innerHTML = table_data;
document.querySelector('#subtotal').innerHTML = total;
document.querySelector('#total').innerHTML = total;