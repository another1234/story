<?php
error_reporting(0);
class Contact extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Contact controller and load header,main content,footer view.
     *   
     */
    public function index() {
        $this->load_model('HeaderModel');

        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));
        
        $this->load_view('user/contact');
        $this->load_view('footer');
    }
    public function contactEshop()
    {
        $address=$_SERVER['HTTP_REFERER'];
        $admin="krushiva.patel@internal.mail";
        $name=$_POST['name'];
        $email=$_POST['email'];
        $subject=$_POST['subject'];
        $message=$_POST['message'];
        $headers = "From: " . $email . "\r\n";
        if(mail($admin,$subject,$message,$headers)){
            echo "<script>";
            echo "alert('Your query/request successfully stored!');";
            echo "window.location.replace(\"$address\");";
            echo "</script>";
        }
        else{
            echo "<script>";
            echo "alert('Unable to catch your query!');";
            echo "window.location.replace(\"$address\");";
            echo "</script>";
        }
    }
}