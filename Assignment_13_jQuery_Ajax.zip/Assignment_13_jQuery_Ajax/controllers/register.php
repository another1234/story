<?php
error_reporting(0);
class Register extends BaseController
{
	/**
	 * @author Tatvasoft
	 * Default method of Register Controller
	 * @params userdata 
     * @return validation user and do login process 
	 */

	public function index()
	{	
		$validationErrors = array();
		
		/*if(isset($_POST['mandatory'])) {
			$this->load_model("RegisterModel");
			
			// echo "Welcome " . $_POST['username'];exit();
			$result=$this->registermodel->insert($_POST);
			if($result==1) {
				$this->load_model("LoginModel");
				if($this->loginmodel->authenticate($_POST['username'], $_POST['password'])) {
					$this->redirect('profile');
				}
			}
			else if($result==2){
				$status=2;
				$msg='Username or email id already exist';
				// exit();
				// echo json_encode(array('status' => 2, 'msg' => 'Username or email id already exist'));
			}else if($result==3){
				echo json_encode(array('status' => 3, 'msg' => 'Can\'t send mail'));
			}else if($result==4){
				echo json_encode(array('status' => 4, 'msg' => 'Unable to register'));
				// $validationErrors = $this->registermodel->getErrors();	
			}
		}	*/
		
		// $this->load_view('header');
		$this->load_model('HeaderModel');

        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));
		
		$this->load_view('user/register', array('validationErrors'=>$validationErrors));
		$this->load_view('footer');
	}
	public function registerUser(){
		if(isset($_POST['mandatory'])) {
			$this->load_model("RegisterModel");
			
			// echo "Welcome " . $_POST['username'];exit();
			$result=$this->registermodel->insert($_POST);
			$this->load_model("LoginModel");
			if($result==1) {
				if($this->loginmodel->authenticate($_POST['username'], $_POST['password'])) {
					// $this->redirect('profile');
					echo json_encode(array('status' => 1, 'msg' => 'Successfully registered!'));
				}
			}
			else if($result==2){
				echo json_encode(array('status' => 2, 'msg' => 'Username or email id already exist'));
			}else if($result==3){
				if($this->loginmodel->authenticate($_POST['username'], $_POST['password'])) {
					// $this->redirect('profile');
					echo json_encode(array('status' => 3, 'msg' => 'Can\'t send mail, Please update your email id!'));
				}
			}else if($result==4){
				echo json_encode(array('status' => 4, 'msg' => 'Unable to register'));
				// $validationErrors = $this->registermodel->getErrors();	
			}
		}	
	}
}
