<?php
error_reporting(0);
class Cart extends BaseController {
    
    public function index() {
        $this->load_model('HeaderModel');

        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));
        
        $this->load_view('user/cart');
        $this->load_view('footer');
    }
    public function updateCart(){
        $jsonArray=json_decode($_POST['dataString'],true);
        // print_r($jsonArray);
        foreach ($jsonArray as $key => $value) {
            $flag=0;
            $idIndex=0;
            // echo $value['id'] . " " . $value['qty'];
            foreach ($_SESSION["cart"] as $index => $v) {
                if ($v['id'] == $value['id']) {
                    $flag=1;
                    $idIndex=$index;
                    $qty=$value['qty'];
                    break;
                }
            }  
            if($flag==1){
                // echo $qty . " ";
                $_SESSION["cart"][$idIndex]['qty']=$qty;
                $subtotal+=$_SESSION["cart"][$idIndex]['qty']*$_SESSION["cart"][$idIndex]['price'];
            }
        }
        $cartHTML=showCart();
        echo json_encode(array('msg'=>'Cart updated Successfully','subtotal'=>$subtotal,'content'=>$cartHTML));
    }
    public function removeItem(){
        $id=$_POST['id'];
        $address=$_SERVER['HTTP_REFERER'];
        foreach ($_SESSION["cart"] as $i => $v) {
            if ($v['id'] == $id) {
                unset($_SESSION["cart"][$i]);
            }
        }
        foreach ($_SESSION["cart"] as $cartItem) {
            $totalPerItem=$cartItem['price']*$cartItem['qty'];
            $subtotal+=$totalPerItem;
        }
        $cartHTML=showCart();
        echo json_encode(array('status'=>1,'msg'=>'Successfully removed product.','content'=>$cartHTML,'subtotal'=>$subtotal));
    }
    public function clearShoppingCart(){
        $address=$_SERVER['HTTP_REFERER'];
        unset($_SESSION["cart"]);
        echo "<script>";
        echo "window.location.replace(\"$address\");";
        echo "</script>";
    }
}